# Program 3b: Check whether a given number is prime using a function

def is_prime(n):
    """Check if a number is prime."""
    if n <= 1:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


num = int(input("Enter a number: "))

if is_prime(num):
    print(f"{num} is a Prime number")
else:
    print(f"{num} is not a Prime number")
