import React, { Component } from 'react';

// Task 13: ReactJS Class Components (State & Props)
// Child Component that receives data via props
class StudentChild extends Component {
  render() {
    return (
      <div style={{ marginTop: '20px', padding: '10px', border: '1px solid blue' }}>
        <h3>Child Component (Displaying Props)</h3>
        <p>Student Name: <strong>{this.props.name}</strong></p>
      </div>
    );
  }
}

// Parent Component that manages state
class App extends Component {
  constructor(props) {
    super(props);
    // Initialize state
    this.state = {
      studentName: "Shriyash Lab"
    };
  }

  // Method to handle input changes
  handleNameChange = (event) => {
    this.setState({ studentName: event.target.value });
  };

  render() {
    return (
      <div style={{ padding: '30px', fontFamily: 'Arial, sans-serif' }}>
        <h1>React Class Component: State & Props</h1>
        
        <div style={{ padding: '20px', border: '1px solid green' }}>
          <h3>Parent Component (Managing State)</h3>
          <label>Enter Student Name: </label>
          <input 
            type="text" 
            value={this.state.studentName} 
            onChange={this.handleNameChange}
            style={{ padding: '5px', marginLeft: '10px' }}
          />
        </div>

        {/* Passing state to child component via props */}
        <StudentChild name={this.state.studentName} />
        
        <StudentManagement />
      </div>
    );
  }
}

// Task 14: React Frontend with Spring Boot Backend
class StudentManagement extends Component {
  constructor(props) {
    super(props);
    this.state = {
      students: [],
      newStudent: { name: '', email: '', course: '' }
    };
  }

  componentDidMount() {
    this.fetchStudents();
  }

  fetchStudents = async () => {
    try {
      const response = await fetch("http://localhost:8082/api/students");
      const data = await response.json();
      this.setState({ students: data });
    } catch (error) {
      console.error("Error fetching students:", error);
    }
  };

  handleInput = (e) => {
    const { name, value } = e.target;
    this.setState(prevState => ({
      newStudent: { ...prevState.newStudent, [name]: value }
    }));
  };

  addStudent = async (e) => {
    e.preventDefault();
    try {
      await fetch("http://localhost:8082/api/students", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(this.state.newStudent)
      });
      this.setState({ newStudent: { name: '', email: '', course: '' } });
      this.fetchStudents();
    } catch (error) {
      console.error("Error adding student:", error);
    }
  };

  render() {
    return (
      <div>
        <h2>Task 14: Student Management (Spring Boot + React)</h2>
        <form onSubmit={this.addStudent} style={{ marginBottom: '20px' }}>
          <input name="name" placeholder="Name" value={this.state.newStudent.name} onChange={this.handleInput} />
          <input name="email" placeholder="Email" value={this.state.newStudent.email} onChange={this.handleInput} />
          <input name="course" placeholder="Course" value={this.state.newStudent.course} onChange={this.handleInput} />
          <button type="submit">Add Student</button>
        </form>
        <table border="1" cellPadding="10" style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th>ID</th><th>Name</th><th>Email</th><th>Course</th>
            </tr>
          </thead>
          <tbody>
            {this.state.students.map(s => (
              <tr key={s.id}>
                <td>{s.id}</td><td>{s.name}</td><td>{s.email}</td><td>{s.course}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

export default App;
